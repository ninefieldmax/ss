package Relfect;

public class Student {
    public String name="藤郡";
    public String genome(){
        return name;
    }
    public void setName(String name){
        this.name=name;
    }
}
